﻿using System;
using System.Diagnostics;
using Openfin.Desktop;
using OpenfinDesktop;
namespace ChannelAPI
{
    class Program
    {
        public static readonly Runtime _runtime;

        static void Main(string[] args)
        {
            MakeProvider();
            Console.WriteLine("Hello World!");
        }

        public static async void MakeProvider()
        {
            Action connected = new Action(ConnectChannel);

            var runtime = Openfin.Desktop.Runtime.GetRuntimeInstance(new RuntimeOptions
            {
                Version = "22.94.65.4"
            });
            runtime.Connect(connected);
         
        }

        public static void ConnectChannel()
        {
            var providerBus = _runtime.InterApplicationBus.Channel.CreateProvider("channelName");

            providerBus.Opened += (identity, payload) =>
            {
                Console.WriteLine("Client connection request identity: ", identity?.ToString());
                Console.WriteLine("Client connection request payload: ", payload?.ToString());
            };

            providerBus.RegisterTopic<Object>("topic", (payload, client) =>
            {
                Console.WriteLine("Action dispatched by client: ", client.RemoteEndpoint);
                Console.WriteLine("Payload sent in dispatch: ", payload?.ToString());
            });
        }
    }
}
